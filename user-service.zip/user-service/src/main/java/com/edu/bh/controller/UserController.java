package com.edu.bh.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.edu.bh.entity.SuperUser;
import com.edu.bh.entity.Users;
import com.edu.bh.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;

	@GetMapping
	public String index() {
		return "User Service Loaded";
	}

	@GetMapping(value ="/getAllUsers")
	public ResponseEntity<List<Users>> getAllUsersV1() {
		List<Users> result = userService.getAllUsers();
		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		return new ResponseEntity<List<Users>>(result, HttpStatus.OK);
	}
	
	@GetMapping(value ="/users" ,produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<List<Users>> getAllUsersV4() {
		List<Users> result = userService.getAllUsers();
		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		return new ResponseEntity<List<Users>>(result, HttpStatus.OK);
	}
	
	@GetMapping(value ="/getAllUsers" ,produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},headers="api-version=2")
	public ResponseEntity<List<SuperUser>> getAllUsersV2() {
		List<SuperUser> result = userService.getAllUsersWithRole();
		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		return new ResponseEntity<List<SuperUser>>(result, HttpStatus.OK);
	}
	
	@GetMapping(value ="/getAllUsers", headers="api-version=1",produces= "application/vnd.company.app-2+json")
	public ResponseEntity<List<SuperUser>> getAllUsersV3() {
		List<SuperUser> result = userService.getAllUsersWithRole();
		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		return new ResponseEntity<List<SuperUser>>(result, HttpStatus.OK);
	}

	@PostMapping(value = "/adduser")
	public ResponseEntity<String> adddUser(@Valid @RequestBody Users user) {
		String result = userService.adddUser(user);
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}

	@PutMapping(value = "/modifyUser")
	public void modifyUser(Users user) {
		userService.modifyUser(user);
	}
	
	@DeleteMapping(value="/deleteUser/{id}")
	public void deleteUser(@PathVariable Long id) {
		userService.deleteUser(id);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler({ MethodArgumentNotValidException.class })
	public Map<String, String> handleValidationException(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});
		return errors;
	}

}
