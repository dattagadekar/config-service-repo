package com.edu.bh.entity;

public class SuperUser {

	private Users users;
	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	private String role = "Super User";

	public SuperUser(String role, Users users2) {
		this.users = users2;
		this.role = role;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
