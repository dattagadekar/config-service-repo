package com.edu.bh.service;

import java.util.List;

import com.edu.bh.entity.SuperUser;
import com.edu.bh.entity.Users;

public interface UserService {
	
	public List<Users> getAllUsers();
	
	public String adddUser(Users user);
	
	public void modifyUser(Users user);

	public void deleteUser(Long id);

	public List<SuperUser> getAllUsersWithRole();
	
	public Users getUserById(Long id);

}
