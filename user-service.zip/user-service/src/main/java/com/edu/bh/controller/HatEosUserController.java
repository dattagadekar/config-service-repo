package com.edu.bh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.bh.service.UserService;

@RestController
@RequestMapping("/hateos")
public class HatEosUserController {
	
	@Autowired
	UserService userService;
	
//	
//	@GetMapping(value="/user/{id}")
//	public Resource<Users> getUserById(@PathVariable Long id) {
//		  Resource<Users> user=new Resource<Users>(userService.getUserById(id));
//          user.add(linkTo(methodOn(HatEosUserController.class).getUserById(id)).withRel("_self"));
//          user.add(linkTo(methodOn(HatEosUserController.class).getAllUsers()).withRel("_all"));
//          return user;
//	}
//
//	
//	
//	@GetMapping(value ="/getAllUsers")
//	public List<Resource<Users>> getAllUsers() {
//		List<Users> result = userService.getAllUsers();
//		List<Resource<Users>> userResource = new ArrayList<Resource<Users>>();
//		for(Users user : result) {
//			userResource.add(getUserResource(user));
//		}
//		return userResource;
//		
//	}
//	
//	private static Resource<Users> getUserResource(Users user){
//		Resource<Users> resource = new Resource<Users>(user);
//		resource.add(linkTo(methodOn(HatEosUserController.class).getUserById(user.getId())).withRel("_self"));
//		return resource;
//	}

	
	
	

}
